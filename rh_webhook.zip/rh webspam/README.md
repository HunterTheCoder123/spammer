๖̶ζ͜͡rheuss web spammer.

🔰 Avant de start:
1 - configue le `config.json`  
>-**token**: ton token  
-**serv**: l'id du serv  
-**name**: le nom du webhooks  
-**avatar**: url de l'avatar  
-**spamMsg**: ton message
-**ChannelMsgCount**: le nombre de message par channel
-**sleepMS**: touche pas

3 - Lance le script dans le cmd :  `node index.js `


DM = ๖̶ζ͜͡rheuss#0002 pour de l'aide.
